<?php
/*
 * Plugin Name:       Custom Post Meta Manager
 * Plugin URI:        http://www.wetinvite.net
 * Description:       Declares a plugin that will create a custom post type displaying Social metaphone.
 * Version:           0.2.0
 * Author:            Prabu.v
 * Author URI:        http://tommcfarlin.com
 * Text Domain:       single-post-meta-manager-locale
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages
 */

if ( ! class_exists( 'Createcusposttype' ) ) {
class Createcusposttype {
	public function __construct(){
		add_action('init', array($this,'create_all_custom_post_type'));
		require_once plugin_dir_path( __FILE__ ) . '/inc/custom_meta_data.php';
		require_once plugin_dir_path( __FILE__ ) . '/inc/custom_post_metadata.php';	
	}	
			function create_all_custom_post_type(){
				register_post_type('allposts',array(
						'labels' => array(
							'name' => 'All Custom Posts',
							'singular_name' => 'Custom Posts',
							'add_new' => 'Add New',
							'add_new_item' => 'Add New Post',
							'edit' => 'Edit',
							'edit_item' => 'Edit Custom Post',
							'new_item' => 'New Custom Post',
							'view' => 'View',
							'view_item' => 'View Custom Post',
							'search_items' => 'Search Custom Post',
							'not_found' => 'No Posts found',
							'not_found_in_trash' => 'No Posts found in Trash',
							'parent' => 'Parent Post',
							'menu_name' => 'Custom Posts',
						),
					'description'         => __( 'Custom post type and social meta description', 'custom_theme' ),
					'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions','trackbacks', 'page-attributes' ),
					'hierarchical'        => false,
					'public'              => true,
					'show_ui'             => true,
					'show_in_menu'        => true,
					'show_in_nav_menus'   => true,
					 'rewrite' => array('slug' => 'custom_post'),
      				  'query_var' => true,
					'show_in_admin_bar'   => true,
					'menu_position'       => 1000,
					'can_export'          => true,
					'has_archive'         => true,
					'exclude_from_search' => false,
					'publicly_queryable'  => true,
					'capability_type'     => 'post',
					));	
					  register_taxonomy('custom_taxonomy', 'allposts', array(
					  'hierarchical' => true,
					  'label' => 'Custom Categories', 
					  'singular_label' => 'Portfolio Tag',
						'query_var' => true, 
						 'show_ui' => true,
						'show_in_nav_menus' => true,
						'rewrite' => array( 
						'slug' => 'custom_categories' )));

			}		
  
		} 	
			add_filter( 'the_content', 'change_single_content' );

			function change_single_content($content){
			    global $post;

			    if (is_single() ){
			        remove_filter( 'the_content', 'change_single_content' ); // this !!
			        ob_start();
			        include  plugin_dir_path( __FILE__ ) . '/inc/templates/single-template.php'; //include single template content
			        return ob_get_clean();
			    }

			    return $content;
			}

			function custom_plu_css() 
			{
			    wp_enqueue_style( 'myCSS1', plugins_url('assets/css/custom-style.css',__FILE__) );
			}

			add_action('wp_enqueue_scripts', 'custom_plu_css');
	}
		global $custompost_meta_fields;
		$custompost_el_fields = new Createcusposttype();