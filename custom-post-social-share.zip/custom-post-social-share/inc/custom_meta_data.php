<?php		
	function custom_meta_box_markup($object)
		{
			wp_nonce_field(basename(__FILE__), "meta-box-nonce");
?>
				<div>
<?php
						$facebook_value = get_post_meta($object->ID, "facebook_value", true);
						if($facebook_value == "")
						{
							?>
								<input name="facebook_value" type="checkbox" value="true">
							<?php
						}
						else if($facebook_value == "true")
						{
							?>  
								<input name="facebook_value" type="checkbox" value="true" checked>
							<?php
						}
					?>
					<label for="meta-box-facebook">Facebook</label>
				<br>
				
					<?php
						$checkbox_twitter = get_post_meta($object->ID, "twitter_value", true);

						if($checkbox_twitter == "")
						{
							?>
								<input name="twitter_value" type="checkbox" value="true">
							<?php
						}
						else if($checkbox_twitter == "true")
						{
							?>  
								<input name="twitter_value" type="checkbox" value="true" checked>
							<?php
						}
					?>
					<label for="meta-box-twitter">Twitter</label>
					<br>
					<?php
						$checkbox_linkedin = get_post_meta($object->ID, "linkedin_value", true);

						if($checkbox_linkedin == "")
						{
							?>
								<input name="linkedin_value" type="checkbox" value="true">
							<?php
						}
						else if($checkbox_linkedin == "true")
						{
							?>  
								<input name="linkedin_value" type="checkbox" value="true" checked>
							<?php
						}
					?>
					<label for="meta-box-linkedin">Linkedin</label>
				</div>
			<?php  
		} 
?>
<?php	
		function add_custom_meta_box(){
		add_meta_box("custom-meta-box", "Social Share", "custom_meta_box_markup", "post", "side", "high", null);
		}
		add_action("add_meta_boxes", "add_custom_meta_box");
	   function save_custom_meta_box($post_id, $post, $update)
		{
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;
    if(!current_user_can("edit_post", $post_id))
        return $post_id;
    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;
    $slug = "post";
    if($slug != $post->post_type)
        return $post_id;
    $meta_box_facebook_value = "";
    $meta_box_twitter_value = "";
    $meta_box_linkedin_value = "";
    if(isset($_POST["facebook_value"]))
    {
        $meta_box_facebook_value = $_POST["facebook_value"];
    }   
    update_post_meta($post_id, "facebook_value", $meta_box_facebook_value);

    if(isset($_POST["twitter_value"]))
    {
        $meta_box_twitter_value = $_POST["twitter_value"];
    }   
    update_post_meta($post_id, "twitter_value", $meta_box_twitter_value);
    if(isset($_POST["linkedin_value"]))
    {
        $meta_box_linkedin_value = $_POST["linkedin_value"];
    }   
    update_post_meta($post_id, "linkedin_value", $meta_box_linkedin_value);
}
add_action("save_post", "save_custom_meta_box", 10, 3); 

?>