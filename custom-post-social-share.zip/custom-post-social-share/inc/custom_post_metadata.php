<?php 

function social_meta_fn() {
    add_meta_box( 'cusm_meta_box',
        'Social Share',
        'display_social_meta_box',
        'allposts', 'side', 'high'
    );
}

add_action( 'admin_init', 'social_meta_fn' );

function display_social_meta_box( $social ) {
    // Retrieve current name of the Director and Movie Rating based on review ID
    $facebook_icon = get_post_meta( $social->ID, 'facebook_value', true );
    $twitter_icon =  get_post_meta( $social->ID, 'twitter_value', true );
	$linkedin_icon = get_post_meta( $social->ID, 'linkedin_value', true );
?>
    <div class="meta-data-fn">
         
		<?php if($facebook_icon == ""){  ?>
         <input name="facebook_value" type="checkbox" value="true">
		<?php } elseif($facebook_icon == "true"){  ?>
		 <input name="facebook_value" type="checkbox" value="true" checked>
		<?php } ?>
		<label for="facebook">Facebook</label>
        <br>
		
		<?php if($twitter_icon == ""){  ?>
            <input name="twitter_value" type="checkbox" value="true">
			<?php } elseif($twitter_icon =="true") { ?>
			<input name="twitter_value" type="checkbox" value="true" checked>
		<?php } ?>
		<label for="twitter">Twitter</label>
		<br>
		
		<?php if($linkedin_icon == "") { ?>
            <input name="linkedin_value" type="checkbox" value="true">
		<?php } elseif($linkedin_icon == "true"){ ?>
	<input name="linkedin_value" type="checkbox" value="true" checked>
		<?php } ?>
		<label for="Linkedin">Linkedin</label>
		
    </div>
<?php } ?>
<?php add_action( 'save_post', 'add_social_fields', 10, 3 ); 

function add_social_fields( $s_id, $post_value ) {

    // Check post type for movie reviews
    if ( $post_value->post_type == 'allposts' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['facebook_value'] ) ) {
            update_post_meta( $s_id, 'facebook_value',$_POST['facebook_value'] );
        }
        if ( isset( $_POST['twitter_value'] ) ) {
            update_post_meta( $s_id, 'twitter_value',$_POST['twitter_value'] );
        }
		 if ( isset( $_POST['linkedin_value'] ) ) {
            update_post_meta( $s_id, 'linkedin_value', $_POST['linkedin_value'] );
        }
    }
}

?>