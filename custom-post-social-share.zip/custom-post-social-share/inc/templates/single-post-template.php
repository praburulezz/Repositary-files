<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		<?php twentyseventeen_edit_link( get_the_ID() ); ?>
	</header><!-- .entry-header -->
	<div class="entry-content">
	<div class="social-list">
	
		<?php
         $facebook_icon = get_post_meta( $post->ID, 'meta-box-facebook', true );
         $twitter_icon =  get_post_meta( $post->ID, 'meta-box-twitter', true );
	     $linkedin_icon = get_post_meta( $post->ID, 'meta-box-linkedin', true );

	if($facebook_icon =='true'){ ?>

	<img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ).'img/facebook.png'; ?>" title="facebook-share">

	<?php }  ?>

	<?php if($twitter_icon == 'true'){ ?>

	<img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ).'img/twitter.png'; ?>" title="Twitter-share">

	<?php } ?>
	<?php if($linkedin_icon == 'true'){ ?>

	<img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ).'img/linkedin.png'; ?>" title="facebook-share">

	<?php } ?>
	</div>



	<?php the_content(); ?>

		</div>

		<?php wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'twentyseventeen' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->